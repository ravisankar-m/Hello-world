# maven-project

Simple Maven Project for Devops
